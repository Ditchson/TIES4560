const AWS = require('aws-sdk');
var docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = function(event, context)
{

  console.log('Body:', event.body);
  console.log('Headers:', event.headers);
  console.log('Method:', event.method);
  console.log('Params:', event.params);
  console.log('Query:', event.query);

    var params = {
  TableName: "Store"
 };
 docClient.scan(params, function(err, data) {
   if (err) context.succeed(err, err.stack); // an error occurred
   else     context.succeed(data);           // successful response
});
}